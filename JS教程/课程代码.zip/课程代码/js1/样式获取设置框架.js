// JavaScript Document


function sgStyle(obj,prop,value)
{
	if(arguments.length==2)
	{
		if(obj.currentStyle)
		{
			return obj.currentStyle[prop];	
		}
		else
		{
			return getComputedStyle(obj,false)[prop];	
		}	
	}
	else
	{
		if(arguments.length==3)
		{
			obj.style[prop]=value;	
		}	
	}	
}