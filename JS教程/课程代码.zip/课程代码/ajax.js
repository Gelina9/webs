// JavaScript Document

function ajax(url,fnSucc,fnFaild)
{
		//创建对象
		var oAjax=new XMLHttpRequest();
		 
		 //连接服务器
		 //方法的应用:第一个参数 数据方法
		 //第二个参数 文件名
		 //第三个参数 通信方式：false 同步
		 // true异步；
		 //open('get','文件名',true)
		 oAjax.open('GET',url,true);
		 //发送请求
		 oAjax.send();
		 //接收返回
		 oAjax.onreadystatechange=function()
		 {
			 if(oAjax.readyState==4)
			 {
				if(oAjax.status==200)
				{
					fnSucc(oAjax.responseText);	
				}
				else
				{
					if(fnFaild)
					{
						fnFaild(oAjax.status);
					}
				}
			  }
		}
	}	
