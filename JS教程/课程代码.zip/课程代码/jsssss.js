// JavaScript Document

function toColor(objectname,objectattribute,objectvalue)
{
  objectname.style[objectattribute]=objectvalue;	
}