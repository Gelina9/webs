// JavaScript Document
//Javascript的注释：单行注释
/* 多行注释 */

 alert("hello");
 //提示框函数
 document.write("hello");
 
 //在文档内部输出
 document.write("<h1>hello</h1>");
 //此方法可以输出HTML标记效果
