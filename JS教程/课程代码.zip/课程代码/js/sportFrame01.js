// JavaScript Document
function sportFrame(obj,prop,endpoint)
{
	clearInterval(obj.timer);
	obj.timer=setInterval(function () {
		var val=0;
		if(prop=='opacity')
		{
			val=Math.round(parseFloat(cssStyle(obj,prop))*100);
		}
		else
		{
		    val=parseInt(cssStyle(obj,prop));
		}
		
		var speed=(endpoint-val)/10;
		
		speed=speed>0?Math.ceil(speed):Math.floor(speed);
		
		if(val==endpoint)
		{
			clearInterval(obj.timer);	
		}
		else
		{   if(prop=='opacity')
			{ 
			 
			    obj.style.filter='alpha(opacity:'+(val+speed)+')';
				obj.style.opacity=(val+speed)/100;	;	
			  
			}
			else
			{
			 cssStyle(obj,prop,val+speed+'px');		
			}
				
		}
		
		},30);	
}

function cssStyle(obj,prop,value)
{
	if(arguments.length==2)
	{
		if(obj.currentStyle)  //获取样式
		{
			return  obj.currentStyle[prop];	//IE 浏览器
		}
		else
		{
			return  getComputedStyle(obj,false)[prop];	 //高版本 FF Chrome
		}	
	}
	else 
	{
		 if(arguments.length==3) //设置样式
		 {
			 obj.style[prop]=value;
		 }	
			
	}
}