// JavaScript Document
	window.onload = function(){
	var aBtn = document.getElementsByClassName("btn");
	var oBox = document.getElementById("box");
	var aUl = oBox.getElementsByTagName('ul')[0];
	var aLi = oBox.getElementsByTagName("li");
	var oNo =document.getElementsByClassName("no");
	for(var i=0;i<aLi.length;i++){
		aLi[i].index = i;
		oNo[i].index = i;
		oNo[i].onclick = function(){
			qiehuan(this,oNo,aUl,'top');
		}
	var times = 0;
	aBtn[0].onclick = function(){
		var b = parseInt(cssStyle(aUl,'top'));
		alert(typeof b);
		if(times==0)
		{
			times =times;
		}
		else{
			times=times-1;
			for(var j=0;j<oNo.length;j++)
			{
				oNo[j].style.backgroundColor = "";
				}
			oNo[times].style.backgroundColor = "blue";
			cssStyle(aUl,'top', b-250+'px');
		}
		};
		aBtn[1].onclick = function(){
		sports(oNo,aUl);	
		};
};

function qiehuan(obj,obj2,obj3,prop){
	var move = -(obj.index)*250;
			times = obj.index;
			for(var j=0;j<obj2.length;j++)
			{
				obj2[j].style.backgroundColor = "";
				}
			obj.style.backgroundColor = "blue";
			cssStyle(obj3,prop,move+'px');
			};
	}
function sports(obj1,obj2){
		if(times==3)
		{
			times = times;
		}
		else{
			times=times+1;
			alert("hello");
			for(var j=0;j<obj1.length;j++)
			{
				obj1[j].style.backgroundColor = "";
				}
			obj1[times].style.backgroundColor = "blue";
			cssStyle(obj2,'top', -250*times+'px');
		}
	
	}
function cssStyle(obj,prop,value){
	if(arguments.length==2)
	{
		if(obj.currentStyle) 
		{
			return  obj.currentStyle[prop];
		}
		else
		{
			return  getComputedStyle(obj,false)[prop];
		}	
	}
	else{ 
		 if(arguments.length==3) { 
			 obj.style[prop]=value;
		 }
	}
}