// JavaScript Document
function getStyle(obj,prop,value)
{
	if(arguments.length == 2){
		if(obj.currentStyle){
			return obj.currentStyle[prop];
			}
		else{
			return obj.getComputedStle[prop];
			}
		}
	else
	{
		if(arguments.length==3){
			return obj.style[prop]=value;
			}
		}
}

function j