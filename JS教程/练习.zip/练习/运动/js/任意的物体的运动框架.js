// JavaScript Document


function sportFrame(obj,prop,endpoint)
{
	clearInterval(obj.timer);
	obj.timer=setInterval(function() {
		
		var val=0;
		if(prop=='opacity')
		{
			val=Math.round(parseFloat(sgStyle(obj,prop))*100);
		}
		else
		{
			val=parseInt(sgStyle(obj,prop));	
		}
		
		var speed=(endpoint-val)/10;
		speed=speed>0?Math.ceil(speed):Math.floor(speed);
		
		if(val==endpoint)
		{
			clearInterval(obj.timer);	
		}
		else
		{
			if(prop=='opacity')
			{
				obj.style.filter='alpha(opacity:'+(val+speed)+')';
				obj.style.opacity=(val+speed)/100;
			}
			else
			{
				sgStyle(obj,prop,val+speed+'px');
			}
		}
		
		
		},30);	
}


function cssStyle(obj,prop,value)
{
	if(arguments.length==2)
	{
		if(obj.currentStyle)
		{
			return obj.currentStyle[prop];	
		}
		else
		{
			return getComputedStyle(obj,false)[prop];	
		}	
	}
	else
	{
		if(arguments.length==3)
		{
			obj.style[prop]=value;	
		}	
	}	
}