// JavaScript Document
function cssStyle(obj,prop,value)
{
	if(arguments.length==2)
	{
		if(obj.currentStyle)  //获取样式
		{
			return  obj.currentStyle[prop];	//IE 浏览器
		}
		else
		{
			return  getComputedStyle(obj,false)[prop];	 //高版本 FF Chrome
		}	
	}
	else 
	{
		 if(arguments.length==3) //设置样式
		 {
			 obj.style[prop]=value;
		 }	
			
	}
}