// JavaScript Document
function getStyle(obj,attr)
{
	if(obj.currentStyle)
	{
		return obj.currentStyle[attr];
		}
	else
	{
		return getComputedStyle(obj,false)[attr];
		}
	}
	
function setStyle(obj,attr,value)
{
	obj.style[attr]=value;
	}
	
function sgStyle()
{
	if(arguments.length==2)
	{
		return getStyle(arguments[0],arguments[1]);
		}
	else
	{
		if(arguments.length==3)
			arguments[0].style[arguments[1]] =arguments[2];
		}
	}